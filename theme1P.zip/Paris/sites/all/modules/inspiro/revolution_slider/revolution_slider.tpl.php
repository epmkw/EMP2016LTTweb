  	<?php print variable_get("slider-revolution"); ?> 
            <script type="text/javascript">
				var revapi;
				jQuery(document).ready(function() {

					   revapi = jQuery('.tp-banner').revolution(
						{
							delay:15000,
							startwidth:1170,
							startheight:500,
							hideThumbs:10,
							fullWidth:"off",
							stopAtSlide:1,
							fullScreen:"on",
							hideArrowsOnMobile:"on",
							touchenabled:"on",
							fullScreenOffsetContainer: "#header, #footer"
						});
				});
			</script>
            <!-- END REVOLUTION SLIDER -->
