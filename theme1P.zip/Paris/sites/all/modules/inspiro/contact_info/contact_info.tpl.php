<!-- Other Contacts -->
<div class="bgpattern">
    <div class="othercontacts">
        <h3><span class="text_color"><?php print variable_get('contact_info_title'); ?></span></h3>
        <ul class="contacts">
            <li><i class="fa fa-map-marker"></i><?php print variable_get('contact_info_street'); ?></li>
            <li><i class="fa fa-envelope" style="left: -3px;"></i><a href="mailto:<?php print variable_get('contact_info_email'); ?>"><?php print variable_get('contact_info_email'); ?></a></li>
            
            <?php if(variable_get('contact_info_email2')): ?>
            	<li><i class="fa fa-envelope" style="left: -3px;"></i><a href="mailto:<?php print variable_get('contact_info_email2'); ?>"><?php print variable_get('contact_info_email2'); ?></a></li>
            <?php endif; ?>  
            <?php if(variable_get('contact_info_phone')): ?>          
            	<li><i class="fa fa-phone"></i><?php print variable_get('contact_info_phone'); ?></li>
            <?php endif; ?> 
            <?php if(variable_get('contact_info_phone2')): ?>
            	<li><i class="fa fa-phone"></i><?php print variable_get('contact_info_phone2'); ?></li>
            <?php endif; ?>   
            <?php if(variable_get('contact_info_phone3')): ?>
            	<li><i class="fa fa-phone"></i><?php print variable_get('contact_info_phone3'); ?></li>  
            <?php endif; ?> 
            <?php if(variable_get('contact_info_fax')): ?>                        
           		<li><i class="fa fa-print"></i><?php print variable_get('contact_info_fax'); ?></li>
            <?php endif; ?> 
        </ul>
    </div>
</div>
<br/>

