<?php 

if (@theme_get_setting('toggle_logo')) {
  @$image = array(
    'path' => @theme_get_setting('logo'),
    'alt' => t('Home'),
  );
  ?>  
  
  <a class="navbar-brand nav-to" href="<?php print base_path(); ?>" title="<?php print t('Home'); ?>" >
                    	<?php print @theme('image', @$image); ?>
			        </a>
<?php } ?>
                    
                    