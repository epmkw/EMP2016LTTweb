(function ($) {
 $(document).ready(function(){
	 

/***************
START: INSPIRO CONTENT TYPE FORM ALTER
****************/

		
	

		
		$('.field-name-field-blog-video').addClass('hide');
		$('.field-name-field-blog-audio').addClass('hide');
		$('.field-name-field-blog-quotation').addClass('hide');
		$('.field-name-field-blog-link').addClass('hide');
		$('.field-name-field-blog-slider').addClass('hide');
		$('.field-name-field-blog-gallery').addClass('hide');
		$('.field-name-field-blog-normal').addClass('hide');
			
		if($("input[id='edit-field-blog-content-type-und-video']:checked").val() == 'Video'){
			$('.field-name-field-blog-video').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-audio']:checked").val() == 'Audio'){
			$('.field-name-field-blog-audio').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-slider']:checked").val() == 'Slider'){
			$('.field-name-field-blog-slider').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-quotation']:checked").val() == 'Quotation'){
			$('.field-name-field-blog-quotation').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-gallery']:checked").val() == 'Gallery'){
			$('.field-name-field-blog-gallery').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-link']:checked").val() == 'Link'){
			$('.field-name-field-blog-link').removeClass('hide');
		}
		if($("input[id='edit-field-blog-content-type-und-normal']:checked").val() == 'Normal'){
			$('.field-name-field-blog-normal').removeClass('hide');
		}
		
		$(".form-item-field-blog-content-type-und input[type='radio']").click(function(event) {			
			
			var elm_attr = $(this).attr('id');
			var elm_arr = elm_attr.split('-');
			
			$('.field-name-field-blog-video').addClass('hide');
			$('.field-name-field-blog-audio').addClass('hide');
			$('.field-name-field-blog-quotation').addClass('hide');
			$('.field-name-field-blog-link').addClass('hide');
			$('.field-name-field-blog-slider').addClass('hide');
			$('.field-name-field-blog-gallery').addClass('hide');
			$('.field-name-field-blog-normal').addClass('hide');	
			$('.field-name-field-blog-'+elm_arr[6]).removeClass('hide');
		    
		});
	
	
/***************
END: INSPIRO CONTENT TYPE FORM ALTER
****************/

 });
	  
})(jQuery);

