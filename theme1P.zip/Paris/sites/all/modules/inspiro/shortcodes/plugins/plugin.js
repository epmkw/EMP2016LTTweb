/**
 * @file Plugin for inserting buttons
 */
(function() {
  CKEDITOR.plugins.add( 'shortcodes',
  {
    init : function( editor )
    {
      /**
       * Link button
       */
      editor.ui.addButton( 'LinkButton',
      {
        label: Drupal.t('Insert Button'),
        command: 'linkbuttonDialog',
        icon: this.path + 'images/button.png'
      });
      editor.addCommand('linkbuttonDialog', new CKEDITOR.dialogCommand('linkbuttonDialog'));
      CKEDITOR.dialog.add('linkbuttonDialog', function (editor) {
        return {
          title: Drupal.t('Button Properties'),
          minWidth: 400,
          minHeight: 200,
          contents:
          [
            {
              id: 'tab1',
              label: Drupal.t('Basic settings'),
              elements:
              [
                {
                  type: 'text',
                  id: 'text',
                  label: Drupal.t('Text'),
                  validate: CKEDITOR.dialog.validate.notEmpty(Drupal.t('Text cannot be empty.')),
                  required: true,
                  setup : function(selectedText) {
                    this.setValue(selectedText);
                  }
                },
                {
                  type: 'text',
                  id: 'url',
                  label: Drupal.t('URL'),
                  validate: CKEDITOR.dialog.validate.notEmpty(Drupal.t('URL cannot be empty.')),
                  required: true
                },
                {
                  type: 'select',
                  id: 'color',
                  label: Drupal.t('Color'),
                  items:
                  [
                    [Drupal.t('<not set>'), ''],
                    [Drupal.t('White'), 'white'],
                    [Drupal.t('Grey'), 'grey'],
                    [Drupal.t('Pink'), 'pink'],
                    [Drupal.t('Orange'), 'orange'],
                    [Drupal.t('Green'), 'blue'],
                    [Drupal.t('Blue'), 'blue'],
                    [Drupal.t('Dark blue'), 'darkblue'],
                    [Drupal.t('Purple'), 'teal'],
                    [Drupal.t('Black'), 'black']
                  ]
                },
                {
                  type: 'select',
                  id: 'target',
                  label: Drupal.t('Target'),
                  items:
                  [
                    [Drupal.t('<not set>'), ''],
                    [Drupal.t('New window (_blank)'), '_blank'],
                    [Drupal.t('Topmost window (_top)'), '_top'],
                    [Drupal.t('Same window (_self)'), '_self'],
                    [Drupal.t('Parent window (_parent)'), '_parent']
                  ]
                },
              ]
            }
          ],
          onShow: function() {
            var sel = editor.getSelection();
            var selectedText = sel.getSelectedText();
            this.setupContent(selectedText);
          },
          onOk: function() {
            var dialog = this;
            var button = '[button href="' + dialog.getValueOf('tab1', 'url') + '"';
            if (dialog.getValueOf('tab1', 'color').length > 0) {
              button += ' color="' + dialog.getValueOf('tab1', 'color') + '"';
            }
            if (dialog.getValueOf('tab1', 'target').length > 0) {
              button += ' target="' + dialog.getValueOf('tab1', 'target') + '"';
            }
            button += ']' + dialog.getValueOf('tab1', 'text') + '[/button]';
            editor.insertHtml(button);
          }
        }
      });

      /**
       * Tooltip
       */
      editor.ui.addButton('Tooltip',
      {
        label: Drupal.t('Insert Tooltip'),
        command: 'tooltipDialog',
        icon: this.path + 'images/tooltip.png'
      });
      editor.addCommand('tooltipDialog', new CKEDITOR.dialogCommand('tooltipDialog'));
      CKEDITOR.dialog.add('tooltipDialog', function (editor) {
        return {
          title: Drupal.t('Tooltip Properties'),
          minWidth: 400,
          minHeight: 200,
          contents:
          [
            {
              id: 'tab1',
              label: Drupal.t('Basic settings'),
              elements:
              [
                {
                  type: 'text',
                  id: 'text',
                  label: Drupal.t('Text'),
                  validate: CKEDITOR.dialog.validate.notEmpty(Drupal.t('Text cannot be empty.')),
                  required: true,
                  setup : function(selectedText) {
                    this.setValue(selectedText);
                  }
                },
                {
                  type: 'text',
                  id: 'tip',
                  label: Drupal.t('Tip'),
                  validate: CKEDITOR.dialog.validate.notEmpty(Drupal.t('Tip cannot be empty.')),
                  required: true
                },
              ]
            }
          ],
          onShow: function() {
            var sel = editor.getSelection();
            var selectedText = sel.getSelectedText();
            this.setupContent(selectedText);
          },
          onOk: function() {
            var dialog = this;
            editor.insertHtml('[tooltip tip="' + dialog.getValueOf('tab1', 'tip') + '"]' + dialog.getValueOf('tab1', 'text') + '[/tooltip]');
          }
        }
      });

      /**
       * Dropcap
       */
      editor.ui.addButton( 'Dropcap',
      {
        label : Drupal.t( 'Insert Dropcap' ),
        command : 'dropcap',
        icon : this.path + 'images/dropcap.png'
      });
      editor.addCommand( 'dropcap',
      {
        exec : function( editor )
        {
          var selection = editor.getSelection();

          if (CKEDITOR.env.ie) {
            selection.unlock(true);
            selectedText = selection.getNative().createRange().text;
          } else {
            selectedText = selection.getNative();
          }

          editor.insertHtml( '[dropcap]' + selectedText + '[/dropcap]' );
        }
      });


    },
  });
})();